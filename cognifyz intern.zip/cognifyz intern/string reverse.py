S=input()
l=S.split()
for i in l:
    print("".join(reversed(i)),end=" ")