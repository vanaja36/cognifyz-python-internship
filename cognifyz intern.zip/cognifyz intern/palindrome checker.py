S = input("Enter the value :")

reverse = S[::-1]

if( S== reverse ):
    print("yes it is palindrome")
else:
    print("No it is not palindrome")